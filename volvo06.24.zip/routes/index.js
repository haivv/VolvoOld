var express = require('express');
var router = express.Router();
const IP = require('ip'); //get client ip
var database = require('../database');


/* GET home page. */
router.get('/', function (req, res, next) {
  const username = req.session.sesUser;
  // Variable exists and is not null or undefined
  res.render('index', {action:'empty', title: 'Admin login page', session:username });





});


router.post('/login', function (req, res, next) {
  var fUsername = req.body.user;
  var fPassword = req.body.pass;
  const query = `SELECT * FROM user where username="${fUsername}" and password="${fPassword}" `;
  database.query(query, function (error, data) {
    if (error) {
      throw error;
    }
    else {
      var total_records = data.length;
      if (total_records > 0) {
        var username = req.session.sesUser = 'admin';

        res.render('portal', { title: 'Volvo Portal', sesion: username });
      }
      else {
        res.render('index', { title: 'Admin login page',action:"login" });
      }

    }

  });


  //   var username = req.session.sesUser = 'admin';

  //  res.render('index',{title: 'Volvo Portal', sesUser: username});
});

router.get('/logout', function (req, res, next) {

    delete req.session.sesUser;
    res.redirect('/');
 
});





router.get('/admin', function (req, res, next) {

  const username = req.session.sesUser;
  if (username) {

    var page = 1;
    var sql = "SELECT * FROM platform";
    database.query(sql, function (error, data) {
      if (error) {
        throw error;
      }
      else {
        var per_page_record = 5;
        var total_records = data.length;
        var total_pages = Math.round(total_records / per_page_record);
        var start_from = (page - 1) * per_page_record;
        var sqlpage = `SELECT * FROM platform ORDER BY id DESC LIMIT ${start_from}, ${per_page_record}`;

        database.query(sqlpage, function (error, dataPage) {
          if (error) {
            throw error;
          }
          else {
            res.render('admin', { title: 'User Tracking System', action: 'list', dataPage: dataPage, total_pages: total_pages, page: page });
          }
        });

      }
    });
  }
  else {
    res.redirect('/');
  }

});


router.get('/admin/:page', function (req, res, next) {

  var page = req.params.page;

  var sql = "SELECT * FROM platform";
  database.query(sql, function (error, data) {
    if (error) {
      throw error;
    }
    else {
      var per_page_record = 5;
      var total_records = data.length;
      var total_pages = Math.round(total_records / per_page_record);
      var start_from = (page - 1) * per_page_record;
      var sqlpage = `SELECT * FROM platform ORDER BY id DESC LIMIT ${start_from}, ${per_page_record}`;

      database.query(sqlpage, function (error, dataPage) {
        if (error) {
          throw error;
        }
        else {
          res.render('admin', { title: 'User Tracking System', action: 'paging', dataPage: dataPage, total_pages: total_pages, page: page });
        }
      });
    }
  });
});




// router.get('/numberpage/:page', function(req, res, next) {
//  // res.send("second page");
//    var id = request.params.page;
//     res.send(id);
//    //res.render('numbepage', { title: 'paging page', page:page });

//  });
router.get('/lobby', function (req, res, next) {
  var sql1 = "SELECT * FROM platform  ORDER BY id DESC LIMIT 1";
  database.query(sql1, function (error, data1) {
    if (error) {
      throw error;
    }
    else {
      var lastid = data1[0].id;
      var sesID1 = req.session.lastID = lastid + 1;
    }
  });

  // ----------- user tracking regiter --------------

  const ipAddress = IP.address();

  const device = req.device.type.toLowerCase();

  var date_ob = new Date();
  var day = ("0" + date_ob.getDate()).slice(-2);
  var month = ("0" + (date_ob.getMonth() + 1)).slice(-2);
  var year = date_ob.getFullYear();
  var date = year + "-" + month + "-" + day;
  var hours = date_ob.getHours();
  var minutes = date_ob.getMinutes();
  var seconds = date_ob.getSeconds();
  var dateTime = year + "-" + month + "-" + day + " " + hours + ":" + minutes + ":" + seconds;

  var query = `
	INSERT INTO platform 
	(ip, platform, logintime) 
	VALUES ("${ipAddress}", "${device}", "${dateTime}")
	`;

  database.query(query, function (error, data) {

    if (error) {
      throw error;
    }
    else {
      // res.send("ok");
      res.render('lobby', { title: 'Lobby', sesLobby: req.session.lastID });
    }
  });


  // res.send(device) //--192.168.0.51--
  // --------------------
});
router.get('/portal', function (req, res, next) {
  const username = req.session.sesUser;
  if (username) {
    res.render('portal', { title: 'User tracking ', sesion:username});
  } else {
    res.redirect('/');
  }

});

module.exports = router;
