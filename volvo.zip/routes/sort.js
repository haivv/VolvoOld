var express = require('express');
var router = express.Router();
var database = require('../database');

router.get('/', function(req, res, next) {
  
    var page = 1;
  var sql = "SELECT * FROM platform ORDER BY id ASC";
  database.query(sql, function (error, data) {
    if (error) {
      throw error;
    }
    else {
      var per_page_record = 5;
      var total_records = data.length;
      var total_pages = Math.round(total_records / per_page_record);
      var start_from = (page - 1) * per_page_record;
      var sqlpage = `SELECT * FROM platform ORDER BY id ASC LIMIT ${start_from}, ${per_page_record}`;

      database.query(sqlpage, function (error, dataPage) {
        if (error) {
          throw error;
        }
        else {
          res.render('sort', { title: 'User Tracking System', action: 'list', dataPage: dataPage, total_pages: total_pages, page: page });
        }
      });

    }
  });
});


router.get('/:page', function (req, res, next) {

    var page = req.params.page;
    
  
    var sql = "SELECT * FROM platform ORDER BY id ASC";
    database.query(sql, function (error, data) {
      if (error) {
        throw error;
      }
      else {
        var per_page_record = 5;
        var total_records = data.length;
        var total_pages = Math.round(total_records / per_page_record);
        var start_from = (page - 1) * per_page_record;
        var sqlpage = `SELECT * FROM platform ORDER BY id ASC LIMIT ${start_from}, ${per_page_record}`;
  
        database.query(sqlpage, function (error, dataPage) {
          if (error) {
            throw error;
          }
          else {
            res.render('sort', { title: 'User Tracking System', action: 'paging', dataPage: dataPage, total_pages: total_pages, page: page });
          }
        });
      }
    });
  });

module.exports = router;
