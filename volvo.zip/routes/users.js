var express = require('express');
const http = require('http');

var router = express.Router();

/* GET users listing. */
router.get('/', function(req, res, next) {
  res.send('respond with a resource');
});


router.get('/add', function(req, res, next) {
  var today = new Date();
  var time = today.getHours() + ":" + today.getMinutes() + ":" + today.getSeconds();
 
  // const clientIP = req.ip;

  // res.send(clientIP);
  // const userAgent = req.headers['user-agent'];
  // res.send(`Client Device: ${userAgent}`);
  

});

module.exports = router;
